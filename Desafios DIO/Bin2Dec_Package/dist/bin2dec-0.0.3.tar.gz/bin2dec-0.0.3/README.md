# Bin2Dec

Description. 
The package Bin2Dec is used to:
	Binary to Decimal Number Converter

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Bin2Dec

```bash
pip install bin2dec
```

## Usage

```python
from bin2dec import conversao
conversao()
```

## Author
Gustavo GS
